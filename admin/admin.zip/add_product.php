<?php
require_once 'pharma_config.php';
require_once 'db.php';
require_once 'SecureSession.php';
require_once 'InputValidator.php';
require_once 'ImageConverter.php';

SecureSession::init();
SecureSession::requireLogin();

$db = getDB();
$errors = [];
$success = '';

// Get all categories for dropdown
$categoriesQuery = "SELECT * FROM categories WHERE is_active = 1 ORDER BY display_order, name";
$categoriesStmt = $db->prepare($categoriesQuery);
$categoriesStmt->execute();
$categories = $categoriesStmt->fetchAll(PDO::FETCH_ASSOC);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_product') {
    
    // Validate CSRF token
    if (!isset($_POST['csrf_token']) || !SecureSession::validateCSRFToken($_POST['csrf_token'])) {
        $errors[] = "Invalid security token";
    } else {
        
        // Get and sanitize input
        $title = InputValidator::sanitizeString($_POST['title'] ?? '');
        $category_id = InputValidator::sanitizeInt($_POST['category_id'] ?? '');
        $price = InputValidator::sanitizeFloat($_POST['price'] ?? '');
        $is_price_visible = isset($_POST['is_price_visible']) ? 1 : 0;
        $unit = InputValidator::sanitizeString($_POST['unit'] ?? '');
        $description = InputValidator::sanitizeString($_POST['description'] ?? '');
        $dosage = InputValidator::sanitizeString($_POST['dosage'] ?? '');
        $composition = InputValidator::sanitizeString($_POST['composition'] ?? '');
        $company_name = InputValidator::sanitizeString($_POST['company_name'] ?? '');
        $keywords = InputValidator::sanitizeString($_POST['keywords'] ?? '');
        $sku = InputValidator::sanitizeString($_POST['sku'] ?? '');
        $stock_quantity = InputValidator::sanitizeInt($_POST['stock_quantity'] ?? '0');
        $prescription_required = isset($_POST['prescription_required']) ? 1 : 0;
        $is_featured = isset($_POST['is_featured']) ? 1 : 0;
        
        // Validate required fields
        if (empty($title)) {
            $errors[] = "Product title is required";
        }
        if (empty($category_id) || $category_id <= 0) {
            $errors[] = "Please select a category";
        }
        if (empty($price) || $price < 0) {
            $errors[] = "Valid price is required";
        }
        if (empty($unit)) {
            $errors[] = "Unit is required";
        }
        
        // Validate lengths
        if (strlen($title) > 255) {
            $errors[] = "Title must be less than 255 characters";
        }
        if (strlen($sku) > 50) {
            $errors[] = "SKU must be less than 50 characters";
        }
        
        // Handle image upload and conversion
        $imageName = null;
        if (isset($_FILES['product_image']) && $_FILES['product_image']['error'] !== UPLOAD_ERR_NO_FILE) {
            if ($_FILES['product_image']['error'] === UPLOAD_ERR_OK) {
                $uploadResult = ImageConverter::convertToAVIF($_FILES['product_image']);
                if ($uploadResult['success']) {
                    $imageName = $uploadResult['filename'];
                    $originalImageName = $uploadResult['original_name'];
                } else {
                    $errors = array_merge($errors, $uploadResult['errors']);
                }
            } else {
                $errors[] = "Error uploading image";
            }
        }
        
        // If no errors, insert into database
        if (empty($errors)) {
            try {
                $db->beginTransaction();
                
                // Insert product
                $query = "INSERT INTO products (
                    title, category_id, price, is_price_visible, unit, description,
                    dosage, composition, company_name, keywords, sku, stock_quantity,
                    prescription_required, is_featured, created_by
                ) VALUES (
                    :title, :category_id, :price, :is_price_visible, :unit, :description,
                    :dosage, :composition, :company_name, :keywords, :sku, :stock_quantity,
                    :prescription_required, :is_featured, :created_by
                )";
                
                $stmt = $db->prepare($query);
                $stmt->execute([
                    ':title' => $title,
                    ':category_id' => $category_id,
                    ':price' => $price,
                    ':is_price_visible' => $is_price_visible,
                    ':unit' => $unit,
                    ':description' => $description,
                    ':dosage' => $dosage,
                    ':composition' => $composition,
                    ':company_name' => $company_name,
                    ':keywords' => $keywords,
                    ':sku' => $sku,
                    ':stock_quantity' => $stock_quantity,
                    ':prescription_required' => $prescription_required,
                    ':is_featured' => $is_featured,
                    ':created_by' => $_SESSION['user_id'] ?? null
                ]);
                
                $productId = $db->lastInsertId();
                
                // Insert image if uploaded
                if ($imageName) {
                    $imageQuery = "INSERT INTO product_images (product_id, image_name, original_name, is_primary) 
                                  VALUES (:product_id, :image_name, :original_name, 1)";
                    $imageStmt = $db->prepare($imageQuery);
                    $imageStmt->execute([
                        ':product_id' => $productId,
                        ':image_name' => $imageName,
                        ':original_name' => $originalImageName
                    ]);
                }
                
                $db->commit();
                $success = "Product added successfully! <a href='product_list.php' class='alert-link'>View Products</a>";
                
                // Clear form
                $_POST = [];
                
            } catch (PDOException $e) {
                $db->rollBack();
                if ($imageName) {
                    ImageConverter::deleteImage($imageName);
                }
                error_log("Database error: " . $e->getMessage());
                if (strpos($e->getMessage(), 'Duplicate entry') !== false) {
                    $errors[] = "SKU already exists. Please use a unique SKU.";
                } else {
                    $errors[] = "Database error: " . $e->getMessage();
                }
            }
        }
    }
}

$pageTitle = "Add Product";
require_once 'include/header.php';
?>

<main id="main" class="main">
    <div class="pagetitle">
        <h1>Add New Product</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="pharma_dashboard.php">Home</a></li>
                <li class="breadcrumb-item"><a href="product_list.php">Products</a></li>
                <li class="breadcrumb-item active">Add Product</li>
            </ol>
        </nav>
    </div>

    <section class="section">
        
        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <h4 class="alert-heading"><i class="bi bi-exclamation-triangle"></i> Error!</h4>
                <ul class="mb-0">
                    <?php foreach ($errors as $error): ?>
                        <li><?php echo htmlspecialchars($error); ?></li>
                    <?php endforeach; ?>
                </ul>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <?php if (!empty($success)): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle"></i> <?php echo $success; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <!-- Add Product Card -->
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Product Information</h5>

                <form method="POST" enctype="multipart/form-data" class="row g-3 needs-validation" novalidate>
                    <input type="hidden" name="csrf_token" value="<?php echo SecureSession::generateCSRFToken(); ?>">
                    <input type="hidden" name="action" value="add_product">

                    <!-- Basic Information -->
                    <div class="col-12">
                        <h6 class="text-primary"><i class="bi bi-info-circle"></i> Basic Information</h6>
                        <hr>
                    </div>

                    <div class="col-md-6">
                        <label for="title" class="form-label">Product Title <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="title" name="title" required 
                               placeholder="e.g., Paracetamol 500mg"
                               value="<?php echo htmlspecialchars($_POST['title'] ?? ''); ?>">
                        <div class="invalid-feedback">Please enter product title.</div>
                    </div>

                    <div class="col-md-6">
                        <label for="category_id" class="form-label">Category <span class="text-danger">*</span></label>
                        <select class="form-select" id="category_id" name="category_id" required>
                            <option value="">Select Category</option>
                            <?php foreach ($categories as $cat): ?>
                                <option value="<?php echo $cat['id']; ?>" 
                                    <?php echo (isset($_POST['category_id']) && $_POST['category_id'] == $cat['id']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($cat['name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <div class="invalid-feedback">Please select a category.</div>
                    </div>

                    <div class="col-md-6">
                        <label for="company_name" class="form-label">Manufacturer/Company Name</label>
                        <input type="text" class="form-control" id="company_name" name="company_name"
                               placeholder="e.g., PharmaCorp Ltd"
                               value="<?php echo htmlspecialchars($_POST['company_name'] ?? ''); ?>">
                    </div>

                    <div class="col-md-3">
                        <label for="sku" class="form-label">SKU <i class="bi bi-question-circle" data-bs-toggle="tooltip" title="Stock Keeping Unit - Unique product code"></i></label>
                        <input type="text" class="form-control" id="sku" name="sku"
                               placeholder="e.g., MED001"
                               value="<?php echo htmlspecialchars($_POST['sku'] ?? ''); ?>">
                        <small class="text-muted">Optional unique code</small>
                    </div>

                    <div class="col-md-3">
                        <label for="stock_quantity" class="form-label">Stock Quantity</label>
                        <input type="number" class="form-control" id="stock_quantity" name="stock_quantity" min="0"
                               placeholder="0"
                               value="<?php echo htmlspecialchars($_POST['stock_quantity'] ?? '0'); ?>">
                    </div>

                    <!-- Pricing & Units -->
                    <div class="col-12 mt-4">
                        <h6 class="text-primary"><i class="bi bi-currency-rupee"></i> Pricing & Units</h6>
                        <hr>
                    </div>

                    <div class="col-md-4">
                        <label for="price" class="form-label">Price (₹) <span class="text-danger">*</span></label>
                        <input type="number" step="0.01" class="form-control" id="price" name="price" required
                               placeholder="0.00"
                               value="<?php echo htmlspecialchars($_POST['price'] ?? ''); ?>">
                        <div class="invalid-feedback">Please enter a valid price.</div>
                    </div>

                    <div class="col-md-4">
                        <label for="unit" class="form-label">Unit <span class="text-danger">*</span></label>
                        <select class="form-select" id="unit" name="unit" required>
                            <option value="">Select Unit</option>
                            <?php foreach (PRODUCT_UNITS as $unit_option): ?>
                                <option value="<?php echo $unit_option; ?>"
                                    <?php echo (isset($_POST['unit']) && $_POST['unit'] == $unit_option) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($unit_option); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <div class="invalid-feedback">Please select a unit.</div>
                    </div>

                    <div class="col-md-4">
                        <label for="dosage" class="form-label">Dosage</label>
                        <input list="dosage-options" class="form-control" id="dosage" name="dosage"
                               placeholder="e.g., 1 tablet twice daily"
                               value="<?php echo htmlspecialchars($_POST['dosage'] ?? ''); ?>">
                        <datalist id="dosage-options">
                            <?php foreach (DOSAGE_OPTIONS as $dosage_option): ?>
                                <option value="<?php echo htmlspecialchars($dosage_option); ?>">
                            <?php endforeach; ?>
                        </datalist>
                        <small class="text-muted">Select from dropdown or type custom</small>
                    </div>

                    <!-- Product Details -->
                    <div class="col-12 mt-4">
                        <h6 class="text-primary"><i class="bi bi-file-text"></i> Product Details</h6>
                        <hr>
                    </div>

                    <div class="col-md-12">
                        <label for="composition" class="form-label">Composition / Active Ingredients</label>
                        <textarea class="form-control" id="composition" name="composition" rows="2"
                                  placeholder="e.g., Paracetamol 500mg, Caffeine 65mg"><?php echo htmlspecialchars($_POST['composition'] ?? ''); ?></textarea>
                        <small class="text-muted">List the active ingredients and their quantities</small>
                    </div>

                    <div class="col-md-12">
                        <label for="description" class="form-label">Description</label>
                        <textarea class="form-control" id="description" name="description" rows="4"
                                  placeholder="Product description, benefits, usage instructions..."><?php echo htmlspecialchars($_POST['description'] ?? ''); ?></textarea>
                    </div>

                    <div class="col-md-12">
                        <label for="keywords" class="form-label">Search Keywords <i class="bi bi-question-circle" data-bs-toggle="tooltip" title="Keywords help users find this product"></i></label>
                        <input type="text" class="form-control" id="keywords" name="keywords" 
                               placeholder="e.g., pain relief, headache, fever, analgesic (comma-separated)"
                               value="<?php echo htmlspecialchars($_POST['keywords'] ?? ''); ?>">
                        <small class="text-muted">Add keywords to improve searchability</small>
                    </div>

                    <!-- Image Upload -->
                    <div class="col-12 mt-4">
                        <h6 class="text-primary"><i class="bi bi-image"></i> Product Image</h6>
                        <hr>
                    </div>

                    <div class="col-md-12">
                        <label for="product_image" class="form-label">Upload Image</label>
                        <input type="file" class="form-control" id="product_image" name="product_image" accept="image/*" onchange="previewImage(this)">
                        <small class="text-muted">Supported: JPG, PNG, WEBP, GIF. Auto-converts to AVIF for compression.</small>
                        
                        <div id="image-preview" class="mt-3" style="display: none;">
                            <p class="mb-2"><strong>Preview:</strong></p>
                            <img id="preview-img" src="" alt="Preview" style="max-width: 300px; max-height: 300px; border: 1px solid #ddd; padding: 5px;">
                        </div>
                    </div>

                    <!-- Product Options -->
                    <div class="col-12 mt-4">
                        <h6 class="text-primary"><i class="bi bi-toggles"></i> Product Options</h6>
                        <hr>
                    </div>

                    <div class="col-md-4">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="is_price_visible" name="is_price_visible" 
                                   <?php echo (isset($_POST['is_price_visible']) || !isset($_POST['action'])) ? 'checked' : ''; ?>>
                            <label class="form-check-label" for="is_price_visible">
                                <i class="bi bi-eye"></i> Show Price to Users
                            </label>
                            <small class="d-block text-muted">Uncheck to hide price</small>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="prescription_required" name="prescription_required"
                                   <?php echo (isset($_POST['prescription_required'])) ? 'checked' : ''; ?>>
                            <label class="form-check-label" for="prescription_required">
                                <i class="bi bi-prescription2"></i> Prescription Required
                            </label>
                            <small class="d-block text-muted">Mark if needs Rx</small>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="is_featured" name="is_featured"
                                   <?php echo (isset($_POST['is_featured'])) ? 'checked' : ''; ?>>
                            <label class="form-check-label" for="is_featured">
                                <i class="bi bi-star"></i> Featured Product
                            </label>
                            <small class="d-block text-muted">Highlight on homepage</small>
                        </div>
                    </div>

                    <!-- Action Buttons -->
                    <div class="col-12 mt-4">
                        <hr>
                        <button type="submit" class="btn btn-primary btn-lg">
                            <i class="bi bi-plus-circle"></i> Add Product
                        </button>
                        <button type="reset" class="btn btn-secondary btn-lg">
                            <i class="bi bi-x-circle"></i> Clear Form
                        </button>
                        <a href="product_list.php" class="btn btn-outline-primary btn-lg">
                            <i class="bi bi-list"></i> View Products
                        </a>
                    </div>
                </form>

            </div>
        </div>

    </section>
</main>

<script>
// Enable Bootstrap validation
(function() {
    'use strict';
    var forms = document.querySelectorAll('.needs-validation');
    Array.prototype.slice.call(forms).forEach(function(form) {
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        }, false);
    });
})();

// Image preview
function previewImage(input) {
    const preview = document.getElementById('image-preview');
    const previewImg = document.getElementById('preview-img');
    
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
            previewImg.src = e.target.result;
            preview.style.display = 'block';
        };
        reader.readAsDataURL(input.files[0]);
    } else {
        preview.style.display = 'none';
    }
}

// Initialize tooltips
var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
    return new bootstrap.Tooltip(tooltipTriggerEl);
});
</script>

<?php
require_once 'include/footer.php';
?>
