<?php
require_once 'pharma_config.php';
require_once 'db.php';
require_once 'SecureSession.php';

SecureSession::init();
SecureSession::requireLogin();

header('Content-Type: application/json');

$query = $_GET['q'] ?? '';

if (strlen($query) < 2) {
    echo json_encode([]);
    exit;
}

$db = getDB();

// Search products
$searchQuery = "SELECT p.id, p.title, p.company_name, p.sku, c.name as category_name
                FROM products p
                LEFT JOIN categories c ON p.category_id = c.id
                WHERE p.is_active = 1 
                AND (p.title LIKE :search 
                     OR p.keywords LIKE :search 
                     OR p.composition LIKE :search 
                     OR p.company_name LIKE :search 
                     OR p.sku LIKE :search)
                ORDER BY 
                    CASE 
                        WHEN p.title LIKE :exact THEN 1
                        WHEN p.title LIKE :starts THEN 2
                        ELSE 3
                    END,
                    p.title
                LIMIT 10";

$stmt = $db->prepare($searchQuery);
$searchParam = '%' . $query . '%';
$exactParam = $query;
$startsParam = $query . '%';

// Ensure all placeholders are correctly bound in the execute method
$stmt->execute([
    ':search' => $searchParam,
    ':exact' => $exactParam,
    ':starts' => $startsParam
]);

$results = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($results);
