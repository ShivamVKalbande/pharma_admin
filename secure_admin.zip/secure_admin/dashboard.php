<?php
require_once 'config.php';
require_once 'db.php';
require_once 'SecureSession.php';
require_once 'InputValidator.php';

SecureSession::init();
SecureSession::requireLogin();

$db = getDB();

// Get statistics
try {
    // Count total tenants
    $stmt = $db->query("SELECT COUNT(*) as total FROM tenant");
    $tenantCount = $stmt->fetch()['total'];
    
    // Count by type
    $stmt = $db->query("
        SELECT tenant_type, COUNT(*) as count 
        FROM tenant 
        GROUP BY tenant_type
    ");
    $tenantsByType = $stmt->fetchAll();
    
    // Recent tenants
    $stmt = $db->query("
        SELECT id, address, city, cost, tenant_type, created_at 
        FROM tenant 
        ORDER BY created_at DESC 
        LIMIT 5
    ");
    $recentTenants = $stmt->fetchAll();
    
} catch (PDOException $e) {
    error_log("Dashboard error: " . $e->getMessage());
    $tenantCount = 0;
    $tenantsByType = [];
    $recentTenants = [];
}

include 'include/header.php';
?>

<main id="main" class="main">
    <div class="pagetitle">
        <h1>Dashboard</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item active">Dashboard</li>
            </ol>
        </nav>
    </div>

    <section class="section dashboard">
        <div class="row">
            <!-- Total Properties Card -->
            <div class="col-xxl-4 col-md-4">
                <div class="card info-card sales-card">
                    <div class="card-body">
                        <h5 class="card-title">Total Properties</h5>
                        <div class="d-flex align-items-center">
                            <div class="card-icon rounded-circle d-flex align-items-center justify-content-center bg-primary text-white">
                                <i class="bi bi-building"></i>
                            </div>
                            <div class="ps-3">
                                <h6><?php echo InputValidator::escapeOutput($tenantCount); ?></h6>
                                <span class="text-muted small">Properties Listed</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Properties by Type -->
            <?php 
            $typeIcons = [
                'rent' => 'bi-key',
                'sale' => 'bi-cash',
                'lease' => 'bi-calendar-check'
            ];
            $typeColors = [
                'rent' => 'bg-success',
                'sale' => 'bg-warning',
                'lease' => 'bg-info'
            ];
            
            foreach ($tenantsByType as $type): 
                $icon = $typeIcons[$type['tenant_type']] ?? 'bi-house';
                $color = $typeColors[$type['tenant_type']] ?? 'bg-secondary';
            ?>
                <div class="col-xxl-4 col-md-4">
                    <div class="card info-card">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo InputValidator::escapeOutput(ucfirst($type['tenant_type'])); ?></h5>
                            <div class="d-flex align-items-center">
                                <div class="card-icon rounded-circle d-flex align-items-center justify-content-center <?php echo $color; ?> text-white">
                                    <i class="<?php echo $icon; ?>"></i>
                                </div>
                                <div class="ps-3">
                                    <h6><?php echo InputValidator::escapeOutput($type['count']); ?></h6>
                                    <span class="text-muted small">Properties</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>

            <!-- Quick Actions -->
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Quick Actions</h5>
                        <div class="row">
                            <div class="col-md-3 mb-3">
                                <a href="tenant.php" class="btn btn-primary w-100">
                                    <i class="bi bi-building"></i> Manage Tenants
                                </a>
                            </div>
                            <div class="col-md-3 mb-3">
                                <a href="gallery.php" class="btn btn-info w-100">
                                    <i class="bi bi-images"></i> Manage Gallery
                                </a>
                            </div>
                            <div class="col-md-3 mb-3">
                                <a href="reports.php" class="btn btn-success w-100">
                                    <i class="bi bi-file-earmark-text"></i> View Reports
                                </a>
                            </div>
                            <div class="col-md-3 mb-3">
                                <a href="settings.php" class="btn btn-secondary w-100">
                                    <i class="bi bi-gear"></i> Settings
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Recent Properties -->
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Recent Properties</h5>
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Address</th>
                                    <th>City</th>
                                    <th>Type</th>
                                    <th>Cost</th>
                                    <th>Added On</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recentTenants as $tenant): ?>
                                    <tr>
                                        <td><?php echo InputValidator::escapeOutput($tenant['id']); ?></td>
                                        <td><?php echo InputValidator::escapeOutput(substr($tenant['address'], 0, 50)) . '...'; ?></td>
                                        <td><?php echo InputValidator::escapeOutput($tenant['city']); ?></td>
                                        <td>
                                            <span class="badge bg-<?php echo $typeColors[$tenant['tenant_type']] ?? 'secondary'; ?>">
                                                <?php echo InputValidator::escapeOutput(ucfirst($tenant['tenant_type'])); ?>
                                            </span>
                                        </td>
                                        <td>₹<?php echo InputValidator::escapeOutput(number_format($tenant['cost'], 2)); ?></td>
                                        <td><?php echo InputValidator::escapeOutput(date('M d, Y', strtotime($tenant['created_at']))); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

<?php include 'include/footer.php'; ?>
