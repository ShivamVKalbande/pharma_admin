<?php
require_once 'config.php';
require_once 'db.php';
require_once 'SecureSession.php';
require_once 'InputValidator.php';
require_once 'FileUploadHandler.php';

SecureSession::init();
SecureSession::requireLogin();

$db = getDB();
$errors = [];
$success = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_tenant') {
    
    // Validate CSRF token
    if (!isset($_POST['csrf_token']) || !SecureSession::validateCSRFToken($_POST['csrf_token'])) {
        $errors[] = "Invalid security token";
    } else {
        // Get and sanitize input
        $totalRooms = InputValidator::sanitizeInt($_POST['totalRooms'] ?? '');
        $address = InputValidator::sanitizeString($_POST['address'] ?? '');
        $totalCost = InputValidator::sanitizeFloat($_POST['totalCost'] ?? '');
        $bedroom = InputValidator::sanitizeInt($_POST['bedroom'] ?? '');
        $kitchen = InputValidator::sanitizeInt($_POST['kitchen'] ?? '');
        $hall = InputValidator::sanitizeInt($_POST['hall'] ?? '');
        $tenantType = InputValidator::sanitizeString($_POST['tenantType'] ?? '');
        $city = InputValidator::sanitizeString($_POST['city'] ?? '');
        $contactName = InputValidator::sanitizeString($_POST['contactName'] ?? '');
        $contactNumber = InputValidator::sanitizeString($_POST['contactNumber'] ?? '');
        $contactEmail = InputValidator::sanitizeEmail($_POST['contactEmail'] ?? '');
        
        // Validate required fields
        $requiredFields = [
            'totalRooms' => 'Total Rooms',
            'address' => 'Address',
            'totalCost' => 'Cost',
            'bedroom' => 'Bedroom',
            'kitchen' => 'Kitchen',
            'hall' => 'Hall',
            'tenantType' => 'Tenant Type',
            'city' => 'City',
            'contactName' => 'Contact Name',
            'contactNumber' => 'Contact Number',
            'contactEmail' => 'Contact Email'
        ];
        
        $errors = array_merge($errors, InputValidator::validateRequired($requiredFields, $_POST));
        
        // Validate specific fields
        if (!InputValidator::validateInt($totalRooms, 1, 50)) {
            $errors[] = "Total rooms must be between 1 and 50";
        }
        if (!InputValidator::validateInt($bedroom, 0, 20)) {
            $errors[] = "Bedroom count must be between 0 and 20";
        }
        if (!InputValidator::validateInt($kitchen, 0, 10)) {
            $errors[] = "Kitchen count must be between 0 and 10";
        }
        if (!InputValidator::validateInt($hall, 0, 10)) {
            $errors[] = "Hall count must be between 0 and 10";
        }
        if (!InputValidator::validateFloat($totalCost)) {
            $errors[] = "Invalid cost amount";
        }
        if (!InputValidator::validateEmail($contactEmail)) {
            $errors[] = "Invalid email address";
        }
        if (!InputValidator::validatePhone($contactNumber)) {
            $errors[] = "Invalid phone number";
        }
        if (!InputValidator::validateTenantType($tenantType)) {
            $errors[] = "Invalid tenant type";
        }
        if (!InputValidator::validateCity($city)) {
            $errors[] = "Invalid city name";
        }
        
        $lengthCheck = InputValidator::validateLength($address, 10, 500, 'Address');
        if ($lengthCheck !== true) {
            $errors[] = $lengthCheck;
        }
        
        // Handle file upload
        $imageName = null;
        if (isset($_FILES['imageName']) && $_FILES['imageName']['error'] !== UPLOAD_ERR_NO_FILE) {
            $uploadResult = FileUploadHandler::uploadImage($_FILES['imageName']);
            if ($uploadResult['success']) {
                $imageName = $uploadResult['filename'];
            } else {
                $errors = array_merge($errors, $uploadResult['errors']);
            }
        } else {
            $errors[] = "Property image is required";
        }
        
        // If no errors, insert into database
        if (empty($errors)) {
            try {
                $stmt = $db->prepare("
                    INSERT INTO tenant (
                        total_rooms, address, cost, bedroom, kitchen, hall, 
                        contact_name, contact_number, contact_email, image_name, 
                        city, tenant_type, created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
                ");
                
                $stmt->execute([
                    $totalRooms, $address, $totalCost, $bedroom, $kitchen, $hall,
                    $contactName, $contactNumber, $contactEmail, $imageName,
                    $city, $tenantType
                ]);
                
                $success = "Tenant property added successfully!";
                
                // Redirect after 2 seconds
                header("refresh:2;url=tenant.php");
            } catch (PDOException $e) {
                error_log("Database error: " . $e->getMessage());
                $errors[] = "Failed to add tenant property. Please try again.";
            }
        }
    }
}

// Get tenant list for display
try {
    $stmt = $db->query("
        SELECT id, total_rooms, address, cost, bedroom, kitchen, hall, 
               contact_name, contact_number, contact_email, image_name, 
               city, tenant_type, created_at 
        FROM tenant 
        ORDER BY created_at DESC
    ");
    $tenants = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
    $tenants = [];
}

include 'include/header.php';
?>

<main id="main" class="main">
    <div class="pagetitle">
        <h1>Tenant Management</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
                <li class="breadcrumb-item active">Tenants</li>
            </ol>
        </nav>
    </div>

    <section class="section">
        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <h5>Errors:</h5>
                <ul>
                    <?php foreach ($errors as $error): ?>
                        <li><?php echo InputValidator::escapeOutput($error); ?></li>
                    <?php endforeach; ?>
                </ul>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        
        <?php if (!empty($success)): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo InputValidator::escapeOutput($success); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">
                            Tenant Properties
                            <button class="btn btn-primary btn-sm float-end" data-bs-toggle="modal" data-bs-target="#addTenantModal">
                                <i class="bi bi-plus-circle"></i> Add New Property
                            </button>
                        </h5>
                        
                        <table class="table table-striped datatable">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Image</th>
                                    <th>Address</th>
                                    <th>City</th>
                                    <th>Type</th>
                                    <th>Rooms</th>
                                    <th>Cost</th>
                                    <th>Contact</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($tenants as $tenant): ?>
                                    <tr>
                                        <td><?php echo InputValidator::escapeOutput($tenant['id']); ?></td>
                                        <td>
                                            <?php if ($tenant['image_name']): ?>
                                                <img src="uploads/<?php echo InputValidator::escapeOutput($tenant['image_name']); ?>" 
                                                     alt="Property" style="width: 50px; height: 50px; object-fit: cover;">
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo InputValidator::escapeOutput($tenant['address']); ?></td>
                                        <td><?php echo InputValidator::escapeOutput($tenant['city']); ?></td>
                                        <td><span class="badge bg-info"><?php echo InputValidator::escapeOutput(ucfirst($tenant['tenant_type'])); ?></span></td>
                                        <td><?php echo InputValidator::escapeOutput($tenant['total_rooms']); ?></td>
                                        <td>₹<?php echo InputValidator::escapeOutput(number_format($tenant['cost'], 2)); ?></td>
                                        <td>
                                            <?php echo InputValidator::escapeOutput($tenant['contact_name']); ?><br>
                                            <small><?php echo InputValidator::escapeOutput($tenant['contact_number']); ?></small>
                                        </td>
                                        <td>
                                            <a href="updateTenant.php?id=<?php echo $tenant['id']; ?>" class="btn btn-sm btn-warning">
                                                <i class="bi bi-pencil"></i>
                                            </a>
                                            <a href="deleteTenant.php?id=<?php echo $tenant['id']; ?>&csrf_token=<?php echo SecureSession::generateCSRFToken(); ?>" 
                                               class="btn btn-sm btn-danger" 
                                               onclick="return confirm('Are you sure you want to delete this property?');">
                                                <i class="bi bi-trash"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

<!-- Add Tenant Modal -->
<div class="modal fade" id="addTenantModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add New Tenant Property</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" enctype="multipart/form-data">
                <?php echo SecureSession::getCSRFField(); ?>
                <input type="hidden" name="action" value="add_tenant">
                
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Total Rooms *</label>
                            <input type="number" class="form-control" name="totalRooms" required min="1" max="50">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Cost *</label>
                            <input type="number" class="form-control" name="totalCost" required min="0" step="0.01">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Bedroom *</label>
                            <input type="number" class="form-control" name="bedroom" required min="0" max="20">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Kitchen *</label>
                            <input type="number" class="form-control" name="kitchen" required min="0" max="10">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Hall *</label>
                            <input type="number" class="form-control" name="hall" required min="0" max="10">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">City *</label>
                            <input type="text" class="form-control" name="city" required maxlength="100">
                        </div>
                        <div class="col-md-12 mb-3">
                            <label class="form-label">Address *</label>
                            <textarea class="form-control" name="address" required rows="3" minlength="10" maxlength="500"></textarea>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Tenant Type *</label>
                            <select class="form-select" name="tenantType" required>
                                <option value="">Select Type</option>
                                <option value="rent">Rent</option>
                                <option value="sale">Sale</option>
                                <option value="lease">Lease</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Property Image *</label>
                            <input type="file" class="form-control" name="imageName" required accept="image/jpeg,image/png,image/webp">
                            <small class="text-muted">Max 5MB. JPG, PNG, WebP only.</small>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Contact Name *</label>
                            <input type="text" class="form-control" name="contactName" required maxlength="100">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Contact Number *</label>
                            <input type="tel" class="form-control" name="contactNumber" required maxlength="15">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Contact Email *</label>
                            <input type="email" class="form-control" name="contactEmail" required maxlength="100">
                        </div>
                    </div>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Add Property</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include 'include/footer.php'; ?>
