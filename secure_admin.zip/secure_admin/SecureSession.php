<?php
/**
 * Secure Session Management Class
 * Handles authentication, CSRF tokens, and session security
 */
class SecureSession {
    
    public static function init() {
        // Configure secure session settings
        ini_set('session.cookie_httponly', 1);
        ini_set('session.use_only_cookies', 1);
        ini_set('session.cookie_secure', 1); // Use only on HTTPS
        ini_set('session.cookie_samesite', 'Strict');
        
        // Start session if not already started
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        
        // Regenerate session ID periodically
        if (!isset($_SESSION['created'])) {
            $_SESSION['created'] = time();
        } else if (time() - $_SESSION['created'] > SESSION_LIFETIME) {
            session_regenerate_id(true);
            $_SESSION['created'] = time();
        }
        
        // Validate session fingerprint
        self::validateFingerprint();
    }
    
    private static function validateFingerprint() {
        $fingerprint = md5($_SERVER['HTTP_USER_AGENT'] . $_SERVER['REMOTE_ADDR']);
        
        if (!isset($_SESSION['fingerprint'])) {
            $_SESSION['fingerprint'] = $fingerprint;
        } else if ($_SESSION['fingerprint'] !== $fingerprint) {
            self::destroy();
            header('Location: login.php?error=session_hijack');
            exit();
        }
    }
    
    public static function login($username) {
        session_regenerate_id(true);
        $_SESSION['user'] = htmlspecialchars($username, ENT_QUOTES, 'UTF-8');
        $_SESSION['user_id'] = self::getUserId($username);
        $_SESSION['login_time'] = time();
        $_SESSION['last_activity'] = time();
        $_SESSION['fingerprint'] = md5($_SERVER['HTTP_USER_AGENT'] . $_SERVER['REMOTE_ADDR']);
    }
    
    private static function getUserId($username) {
        $db = getDB();
        $stmt = $db->prepare("SELECT id FROM user WHERE username = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch();
        return $user ? $user['id'] : null;
    }
    
    public static function isLoggedIn() {
        if (!isset($_SESSION['user']) || !isset($_SESSION['last_activity'])) {
            return false;
        }
        
        // Check for session timeout
        if (time() - $_SESSION['last_activity'] > SESSION_LIFETIME) {
            self::destroy();
            return false;
        }
        
        $_SESSION['last_activity'] = time();
        return true;
    }
    
    public static function requireLogin() {
        if (!self::isLoggedIn()) {
            header('Location: login.php?error=auth_required');
            exit();
        }
    }
    
    public static function destroy() {
        $_SESSION = [];
        
        if (isset($_COOKIE[session_name()])) {
            setcookie(session_name(), '', time() - 3600, '/');
        }
        
        session_destroy();
    }
    
    // CSRF Token Management
    public static function generateCSRFToken() {
        if (!isset($_SESSION['csrf_token']) || !isset($_SESSION['csrf_token_time']) || 
            (time() - $_SESSION['csrf_token_time'] > CSRF_TOKEN_EXPIRY)) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            $_SESSION['csrf_token_time'] = time();
        }
        return $_SESSION['csrf_token'];
    }
    
    public static function validateCSRFToken($token) {
        if (!isset($_SESSION['csrf_token']) || !isset($_SESSION['csrf_token_time'])) {
            return false;
        }
        
        if (time() - $_SESSION['csrf_token_time'] > CSRF_TOKEN_EXPIRY) {
            return false;
        }
        
        return hash_equals($_SESSION['csrf_token'], $token);
    }
    
    public static function getCSRFField() {
        $token = self::generateCSRFToken();
        return '<input type="hidden" name="csrf_token" value="' . htmlspecialchars($token, ENT_QUOTES, 'UTF-8') . '">';
    }
    
    public static function getUsername() {
        return $_SESSION['user'] ?? null;
    }
    
    public static function getUserId() {
        return $_SESSION['user_id'] ?? null;
    }
}
?>
