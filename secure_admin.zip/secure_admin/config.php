<?php
/**
 * Secure Configuration File
 * Store sensitive data in environment variables or .env file
 */

// Error Reporting - Set to 0 in production
error_reporting(E_ALL);
ini_set('display_errors', 0); // Disable for production
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/logs/php-error.log');

// Database Configuration - Use environment variables
define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
define('DB_USER', getenv('DB_USER') ?: 'urban_nest_user');
define('DB_PASS', getenv('DB_PASS') ?: 'CHANGE_THIS_PASSWORD');
define('DB_NAME', getenv('DB_NAME') ?: 'db_urban_nest');
define('DB_CHARSET', 'utf8mb4');

// Security Settings
define('SESSION_LIFETIME', 3600); // 1 hour
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOGIN_LOCKOUT_TIME', 900); // 15 minutes
define('CSRF_TOKEN_EXPIRY', 3600); // 1 hour

// File Upload Settings
define('UPLOAD_PATH', __DIR__ . '/uploads/');
define('GALLERY_UPLOAD_PATH', __DIR__ . '/uploads/gallery/');
define('MAX_FILE_SIZE', 5242880); // 5MB
define('ALLOWED_IMAGE_TYPES', ['image/jpeg', 'image/png', 'image/webp']);
define('ALLOWED_EXTENSIONS', ['jpg', 'jpeg', 'png', 'webp']);

// Application Settings
define('SITE_URL', getenv('SITE_URL') ?: 'http://localhost');
define('ADMIN_EMAIL', getenv('ADMIN_EMAIL') ?: 'admin@urbannest.com');

// Security Headers
header('X-Frame-Options: SAMEORIGIN');
header('X-Content-Type-Options: nosniff');
header('X-XSS-Protection: 1; mode=block');
header('Referrer-Policy: strict-origin-when-cross-origin');
header("Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline';");

// Ensure uploads directory exists
if (!file_exists(UPLOAD_PATH)) {
    mkdir(UPLOAD_PATH, 0755, true);
}
if (!file_exists(GALLERY_UPLOAD_PATH)) {
    mkdir(GALLERY_UPLOAD_PATH, 0755, true);
}
if (!file_exists(__DIR__ . '/logs')) {
    mkdir(__DIR__ . '/logs', 0755, true);
}
?>
