# Urban Nest Admin - Installation & Setup Guide

## 📋 Prerequisites

- PHP 7.4 or higher (PHP 8.0+ recommended)
- MySQL 5.7+ or MariaDB 10.3+
- Apache/Nginx web server
- Composer (optional, for dependencies)
- SSL certificate (required for production)

## 🚀 Installation Steps

### 1. Upload Files

Upload all files from the `secure_admin` folder to your web server:
```bash
/var/www/html/admin/
├── config.php
├── db.php
├── SecureSession.php
├── InputValidator.php
├── FileUploadHandler.php
├── login.php
├── dashboard.php
├── tenant.php
├── deleteTenant.php
├── logout.php
├── database_schema.sql
├── uploads/
├── logs/
└── include/
```

### 2. Set File Permissions

```bash
# Navigate to admin directory
cd /var/www/html/admin

# Set directory permissions
chmod 755 .
chmod 755 uploads
chmod 755 logs

# Set file permissions
chmod 644 *.php
chmod 644 *.sql
chmod 644 *.md

# Protect sensitive files
chmod 600 .env (if using)
```

### 3. Create Database

```bash
# Login to MySQL
mysql -u root -p

# Create database and user
CREATE DATABASE db_urban_nest CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'urban_nest_user'@'localhost' IDENTIFIED BY 'YOUR_STRONG_PASSWORD';
GRANT SELECT, INSERT, UPDATE, DELETE ON db_urban_nest.* TO 'urban_nest_user'@'localhost';
FLUSH PRIVILEGES;
EXIT;

# Import schema
mysql -u root -p db_urban_nest < database_schema.sql
```

### 4. Configure Environment

Edit `config.php` and update:
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'urban_nest_user');
define('DB_PASS', 'YOUR_STRONG_PASSWORD');
define('DB_NAME', 'db_urban_nest');
define('SITE_URL', 'https://yourdomain.com');
define('ADMIN_EMAIL', 'admin@yourdomain.com');
```

**Better Option:** Use environment variables or `.env` file:
```bash
# Create .env file
cp .env.example .env

# Edit .env
nano .env
```

### 5. Test Installation

Visit: `https://yourdomain.com/admin/login.php`

**Default Login:**
- Username: `admin`
- Password: `Admin@123`

**⚠️ IMPORTANT:** Change this password immediately after first login!

### 6. Change Default Password

```bash
# Generate new password hash
php -r "echo password_hash('YourNewPassword123!', PASSWORD_DEFAULT);"

# Update database
mysql -u root -p db_urban_nest
UPDATE user SET password='PASTE_HASH_HERE' WHERE username='admin';
EXIT;
```

### 7. Configure Apache/Nginx

#### Apache (.htaccess)
Create `.htaccess` in admin directory:
```apache
RewriteEngine On

# Force HTTPS
RewriteCond %{HTTPS} off
RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]

# Prevent directory listing
Options -Indexes

# Protect sensitive files
<FilesMatch "\.(env|sql|md|log|git)$">
    Require all denied
</FilesMatch>

# Security headers
<IfModule mod_headers.c>
    Header set X-Frame-Options "SAMEORIGIN"
    Header set X-Content-Type-Options "nosniff"
    Header set X-XSS-Protection "1; mode=block"
    Header set Referrer-Policy "strict-origin-when-cross-origin"
</IfModule>
```

#### Nginx Configuration
```nginx
server {
    listen 443 ssl http2;
    server_name yourdomain.com;
    root /var/www/html;
    index login.php;

    # SSL Configuration
    ssl_certificate /path/to/cert.pem;
    ssl_certificate_key /path/to/key.pem;

    # Security Headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    
    # PHP Processing
    location ~ \.php$ {
        fastcgi_pass unix:/var/run/php/php8.0-fpm.sock;
        fastcgi_index login.php;
        include fastcgi_params;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
    }
    
    # Deny access to sensitive files
    location ~ \.(env|sql|md|log|git)$ {
        deny all;
    }
    
    # Uploads
    location /uploads {
        valid_referers server_names;
        if ($invalid_referer) {
            return 403;
        }
    }
}
```

### 8. SSL Certificate Setup (Let's Encrypt)

```bash
# Install Certbot
sudo apt update
sudo apt install certbot python3-certbot-apache

# Get certificate
sudo certbot --apache -d yourdomain.com

# Auto-renewal (already configured by certbot)
sudo certbot renew --dry-run
```

---

## 🔧 Configuration Options

### Session Settings
In `config.php`:
```php
define('SESSION_LIFETIME', 3600); // 1 hour
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOGIN_LOCKOUT_TIME', 900); // 15 minutes
```

### File Upload Settings
```php
define('MAX_FILE_SIZE', 5242880); // 5MB
define('ALLOWED_IMAGE_TYPES', ['image/jpeg', 'image/png', 'image/webp']);
```

### Email Settings (if implementing notifications)
```php
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USER', 'your-email@gmail.com');
define('SMTP_PASS', 'your-app-password');
```

---

## 📊 Database Maintenance

### Regular Backups
```bash
# Create backup script
nano /usr/local/bin/backup_urbannest.sh

#!/bin/bash
BACKUP_DIR="/backups/urbannest"
DATE=$(date +%Y%m%d_%H%M%S)
mkdir -p $BACKUP_DIR
mysqldump -u urban_nest_user -p db_urban_nest > $BACKUP_DIR/db_backup_$DATE.sql
find $BACKUP_DIR -name "*.sql" -mtime +30 -delete

# Make executable
chmod +x /usr/local/bin/backup_urbannest.sh

# Add to crontab (daily at 2 AM)
crontab -e
0 2 * * * /usr/local/bin/backup_urbannest.sh
```

### Database Optimization
```sql
-- Run monthly
OPTIMIZE TABLE tenant;
OPTIMIZE TABLE gallery;
OPTIMIZE TABLE user;
ANALYZE TABLE tenant;
```

---

## 🧪 Testing

### Test Security Features
1. Test CSRF protection (try submitting form without token)
2. Test SQL injection (try `admin' OR '1'='1`)
3. Test XSS (try `<script>alert('XSS')</script>`)
4. Test file upload (try uploading .php file)
5. Test rate limiting (try 6+ failed logins)
6. Test session timeout (wait 1 hour)

### Performance Testing
```bash
# Install Apache Bench
sudo apt install apache2-utils

# Test response time
ab -n 100 -c 10 https://yourdomain.com/admin/login.php
```

---

## 🐛 Troubleshooting

### Issue: Cannot connect to database
**Solution:**
1. Check database credentials in config.php
2. Verify MySQL is running: `sudo service mysql status`
3. Check user permissions: `SHOW GRANTS FOR 'urban_nest_user'@'localhost';`

### Issue: File uploads not working
**Solution:**
1. Check directory permissions: `ls -la uploads/`
2. Verify PHP upload settings in php.ini
3. Check upload_max_filesize and post_max_size

### Issue: Sessions not working
**Solution:**
1. Check session directory: `php -i | grep session.save_path`
2. Verify permissions on session directory
3. Ensure HTTPS is configured for secure cookies

### Issue: Images not displaying
**Solution:**
1. Check file permissions in uploads directory
2. Verify image paths in database
3. Check browser console for 404 errors

---

## 📝 Post-Installation Checklist

- [ ] Database created and schema imported
- [ ] Default admin password changed
- [ ] File permissions set correctly
- [ ] SSL certificate installed and working
- [ ] .htaccess or Nginx config applied
- [ ] Environment variables configured
- [ ] Error logging enabled and working
- [ ] Backup system configured
- [ ] Security headers verified
- [ ] All features tested
- [ ] Documentation reviewed

---

## 🔒 Security Hardening (Production)

1. **Disable PHP functions:**
```ini
disable_functions = exec,passthru,shell_exec,system,proc_open,popen
```

2. **Hide PHP version:**
```ini
expose_php = Off
```

3. **Configure firewall:**
```bash
sudo ufw allow 22
sudo ufw allow 80
sudo ufw allow 443
sudo ufw enable
```

4. **Enable fail2ban:**
```bash
sudo apt install fail2ban
sudo systemctl enable fail2ban
sudo systemctl start fail2ban
```

5. **Regular updates:**
```bash
# Create update script
sudo apt update && sudo apt upgrade -y
```

---

## 📚 Additional Resources

- [OWASP Security Guide](https://owasp.org/www-project-web-security-testing-guide/)
- [PHP Security Best Practices](https://www.php.net/manual/en/security.php)
- [MySQL Security](https://dev.mysql.com/doc/refman/8.0/en/security.html)

---

## 💬 Support

For issues or questions:
- Email: support@urbannest.com
- Documentation: See SECURITY.md
- GitHub Issues: [if applicable]

---

**Remember:** Always test in a staging environment before deploying to production!
