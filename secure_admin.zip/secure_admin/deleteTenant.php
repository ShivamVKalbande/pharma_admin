<?php
require_once 'config.php';
require_once 'db.php';
require_once 'SecureSession.php';
require_once 'InputValidator.php';
require_once 'FileUploadHandler.php';

SecureSession::init();
SecureSession::requireLogin();

// Validate CSRF token
if (!isset($_GET['csrf_token']) || !SecureSession::validateCSRFToken($_GET['csrf_token'])) {
    die("Invalid security token");
}

// Get and validate tenant ID
$id = $_GET['id'] ?? null;

if (!$id || !InputValidator::validateInt($id, 1)) {
    header("Location: tenant.php?error=invalid_id");
    exit();
}

try {
    $db = getDB();
    
    // Get tenant details using prepared statement
    $stmt = $db->prepare("SELECT image_name FROM tenant WHERE id = ?");
    $stmt->execute([$id]);
    $tenant = $stmt->fetch();
    
    if (!$tenant) {
        header("Location: tenant.php?error=not_found");
        exit();
    }
    
    // Delete the image file if it exists
    if ($tenant['image_name']) {
        $deleteResult = FileUploadHandler::deleteFile($tenant['image_name']);
        if (!$deleteResult['success']) {
            error_log("Failed to delete image: " . ($deleteResult['error'] ?? 'Unknown error'));
        }
    }
    
    // Delete tenant record from database
    $stmt = $db->prepare("DELETE FROM tenant WHERE id = ?");
    $stmt->execute([$id]);
    
    // Log deletion
    $username = SecureSession::getUsername();
    error_log("Tenant {$id} deleted by {$username}");
    
    header("Location: tenant.php?success=deleted");
    exit();
    
} catch (PDOException $e) {
    error_log("Delete tenant error: " . $e->getMessage());
    header("Location: tenant.php?error=delete_failed");
    exit();
}
?>
