-- Secure Database Schema for Urban Nest Admin
-- Run this script to create/update your database

-- Create database if not exists
CREATE DATABASE IF NOT EXISTS db_urban_nest CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE db_urban_nest;

-- Drop existing tables if they exist (CAUTION: This will delete data!)
-- Comment out if you want to preserve existing data
DROP TABLE IF EXISTS `gallery`;
DROP TABLE IF EXISTS `tenant`;
DROP TABLE IF EXISTS `user`;
DROP TABLE IF EXISTS `login_attempts`;

-- User table with secure password storage
CREATE TABLE `user` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `username` VARCHAR(50) NOT NULL UNIQUE,
    `password` VARCHAR(255) NOT NULL COMMENT 'Password hash using password_hash()',
    `email` VARCHAR(100) NOT NULL UNIQUE,
    `full_name` VARCHAR(100),
    `role` ENUM('admin', 'manager', 'user') DEFAULT 'user',
    `status` ENUM('active', 'inactive', 'locked') DEFAULT 'active',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `last_login` TIMESTAMP NULL,
    `password_changed_at` TIMESTAMP NULL,
    PRIMARY KEY (`id`),
    INDEX `idx_username` (`username`),
    INDEX `idx_email` (`email`),
    INDEX `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tenant/Property table with enhanced structure
CREATE TABLE `tenant` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `total_rooms` INT(11) NOT NULL,
    `address` TEXT NOT NULL,
    `cost` DECIMAL(12,2) NOT NULL,
    `bedroom` INT(11) NOT NULL DEFAULT 0,
    `kitchen` INT(11) NOT NULL DEFAULT 0,
    `hall` INT(11) NOT NULL DEFAULT 0,
    `bathroom` INT(11) DEFAULT 0,
    `contact_name` VARCHAR(100) NOT NULL,
    `contact_number` VARCHAR(15) NOT NULL,
    `contact_email` VARCHAR(100) NOT NULL,
    `image_name` VARCHAR(255) DEFAULT NULL,
    `city` VARCHAR(100) NOT NULL,
    `tenant_type` ENUM('rent', 'sale', 'lease') NOT NULL,
    `status` ENUM('available', 'occupied', 'maintenance', 'sold') DEFAULT 'available',
    `featured` TINYINT(1) DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `created_by` INT(11) DEFAULT NULL,
    PRIMARY KEY (`id`),
    INDEX `idx_city` (`city`),
    INDEX `idx_tenant_type` (`tenant_type`),
    INDEX `idx_status` (`status`),
    INDEX `idx_cost` (`cost`),
    INDEX `idx_created_at` (`created_at`),
    FOREIGN KEY (`created_by`) REFERENCES `user`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Gallery table
CREATE TABLE `gallery` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `title` VARCHAR(200) NOT NULL,
    `description` TEXT,
    `image_name` VARCHAR(255) NOT NULL,
    `category` VARCHAR(50) DEFAULT 'general',
    `display_order` INT(11) DEFAULT 0,
    `is_active` TINYINT(1) DEFAULT 1,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `created_by` INT(11) DEFAULT NULL,
    PRIMARY KEY (`id`),
    INDEX `idx_category` (`category`),
    INDEX `idx_is_active` (`is_active`),
    INDEX `idx_display_order` (`display_order`),
    FOREIGN KEY (`created_by`) REFERENCES `user`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Login attempts table for rate limiting
CREATE TABLE `login_attempts` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `username` VARCHAR(50) NOT NULL,
    `ip_address` VARCHAR(45) NOT NULL,
    `attempt_time` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `success` TINYINT(1) DEFAULT 0,
    PRIMARY KEY (`id`),
    INDEX `idx_username_time` (`username`, `attempt_time`),
    INDEX `idx_ip_time` (`ip_address`, `attempt_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Activity log table for audit trail
CREATE TABLE `activity_log` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `user_id` INT(11) DEFAULT NULL,
    `action` VARCHAR(100) NOT NULL,
    `table_name` VARCHAR(50),
    `record_id` INT(11),
    `description` TEXT,
    `ip_address` VARCHAR(45),
    `user_agent` VARCHAR(255),
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `idx_user_id` (`user_id`),
    INDEX `idx_action` (`action`),
    INDEX `idx_created_at` (`created_at`),
    FOREIGN KEY (`user_id`) REFERENCES `user`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert default admin user
-- Default password: Admin@123 (PLEASE CHANGE THIS IMMEDIATELY!)
-- Password hash is generated using: password_hash('Admin@123', PASSWORD_DEFAULT)
INSERT INTO `user` (`username`, `password`, `email`, `full_name`, `role`, `status`) VALUES
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin@urbannest.com', 'Administrator', 'admin', 'active');

-- Create a database user with limited privileges (recommended for production)
-- Run this from a root MySQL session:
/*
CREATE USER IF NOT EXISTS 'urban_nest_user'@'localhost' IDENTIFIED BY 'CHANGE_THIS_PASSWORD';
GRANT SELECT, INSERT, UPDATE, DELETE ON db_urban_nest.* TO 'urban_nest_user'@'localhost';
GRANT FILE ON *.* TO 'urban_nest_user'@'localhost'; -- Only if needed for file operations
FLUSH PRIVILEGES;
*/

-- Create view for statistics (optional)
CREATE OR REPLACE VIEW `property_statistics` AS
SELECT 
    tenant_type,
    status,
    COUNT(*) as total_count,
    AVG(cost) as avg_cost,
    MIN(cost) as min_cost,
    MAX(cost) as max_cost
FROM tenant
GROUP BY tenant_type, status;

-- Add some sample data for testing (optional)
/*
INSERT INTO `tenant` (
    `total_rooms`, `address`, `cost`, `bedroom`, `kitchen`, `hall`, 
    `contact_name`, `contact_number`, `contact_email`, `city`, `tenant_type`
) VALUES
(3, '123 Main Street, Downtown Area', 25000.00, 2, 1, 1, 'John Doe', '9876543210', 'john@example.com', 'Mumbai', 'rent'),
(4, '456 Park Avenue, Sector 5', 5000000.00, 3, 1, 1, 'Jane Smith', '9876543211', 'jane@example.com', 'Delhi', 'sale'),
(2, '789 Lake View, Garden District', 18000.00, 1, 1, 1, 'Bob Johnson', '9876543212', 'bob@example.com', 'Bangalore', 'lease');
*/

-- Security recommendations comments:
-- 1. Change default admin password immediately after setup
-- 2. Use environment variables for database credentials
-- 3. Enable MySQL SSL connections
-- 4. Regularly backup database
-- 5. Enable MySQL audit logging
-- 6. Use prepared statements only (already implemented in code)
-- 7. Limit database user privileges
-- 8. Keep MySQL updated

-- Performance optimization indexes are already included above
-- For large datasets, consider partitioning the tenant table by city or date
