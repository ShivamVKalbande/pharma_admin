# Security Quick Reference Card

## 🚨 CRITICAL: First Steps After Installation

1. ✅ Change default admin password
2. ✅ Update config.php with your database credentials
3. ✅ Set proper file permissions (755 dirs, 644 files)
4. ✅ Enable HTTPS/SSL
5. ✅ Test login and basic functionality
6. ✅ Review error logs

---

## 🔒 Security Checklist

### Before Going Live
- [ ] Default password changed
- [ ] Database credentials updated
- [ ] File permissions set correctly
- [ ] HTTPS enabled and working
- [ ] .htaccess or nginx config applied
- [ ] Error logging enabled
- [ ] Backup system configured
- [ ] All test data removed
- [ ] Security headers verified
- [ ] CSRF protection tested

### Weekly Checks
- [ ] Review error logs
- [ ] Check failed login attempts
- [ ] Verify backups are running
- [ ] Check for suspicious files in uploads
- [ ] Review recent tenant additions

### Monthly Checks
- [ ] Test backup restoration
- [ ] Update PHP/MySQL if needed
- [ ] Review user accounts
- [ ] Check file permissions
- [ ] Audit database for anomalies

---

## 🔑 Password Requirements

- Minimum 8 characters
- At least 1 uppercase letter
- At least 1 lowercase letter
- At least 1 number
- At least 1 special character
- Not in common password list

### Generate Strong Password
```bash
# Linux/Mac
openssl rand -base64 12

# Or use online generator (trusted sites only)
# Example: https://passwordsgenerator.net/
```

---

## 🚫 Common Mistakes to Avoid

1. ❌ Using default credentials
2. ❌ Not enabling HTTPS
3. ❌ Weak passwords
4. ❌ Not setting file permissions
5. ❌ Ignoring error logs
6. ❌ No backups
7. ❌ Using root database user
8. ❌ Exposing .env files
9. ❌ Not updating regularly
10. ❌ Testing in production

---

## 📝 File Permissions Reference

```bash
# Directories
chmod 755 admin/
chmod 755 uploads/
chmod 755 logs/
chmod 755 include/

# PHP Files
chmod 644 *.php

# Sensitive Files
chmod 600 .env
chmod 600 config.php (if contains credentials)

# Uploads
chmod 644 uploads/*.png
chmod 644 uploads/*.jpg
```

---

## 🔧 Configuration Quick Reference

### config.php Settings
```php
// Session
SESSION_LIFETIME = 3600        // 1 hour
MAX_LOGIN_ATTEMPTS = 5         // 5 tries
LOGIN_LOCKOUT_TIME = 900       // 15 minutes

// File Upload
MAX_FILE_SIZE = 5242880        // 5MB
ALLOWED_TYPES = jpg,png,webp   // Image types
```

### PHP Settings (php.ini)
```ini
upload_max_filesize = 5M
post_max_size = 6M
max_execution_time = 30
memory_limit = 128M
display_errors = Off
log_errors = On
```

---

## 🗄️ Database Quick Commands

### Backup
```bash
mysqldump -u urban_nest_user -p db_urban_nest > backup.sql
```

### Restore
```bash
mysql -u urban_nest_user -p db_urban_nest < backup.sql
```

### Change Admin Password
```sql
-- Generate hash first in PHP:
-- password_hash('NewPassword123!', PASSWORD_DEFAULT)

UPDATE user 
SET password = '$2y$10$...' 
WHERE username = 'admin';
```

### Check Login Attempts
```sql
SELECT username, COUNT(*) as attempts 
FROM login_attempts 
WHERE attempt_time > NOW() - INTERVAL 15 MINUTE 
GROUP BY username;
```

---

## 🐛 Troubleshooting Quick Fixes

### Problem: Can't login
```
Solution 1: Check credentials
Solution 2: Clear browser cache/cookies
Solution 3: Check if locked out (wait 15 min)
Solution 4: Verify database connection
Solution 5: Check error logs
```

### Problem: File upload fails
```
Solution 1: Check uploads/ permissions (755)
Solution 2: Verify file size (max 5MB)
Solution 3: Check file type (jpg/png/webp only)
Solution 4: Check PHP upload settings
Solution 5: Check disk space
```

### Problem: Session expires immediately
```
Solution 1: Enable HTTPS
Solution 2: Check session.cookie_secure in php.ini
Solution 3: Verify session directory permissions
Solution 4: Check server time
```

### Problem: CSRF token error
```
Solution 1: Refresh page
Solution 2: Clear cookies
Solution 3: Check config.php for SESSION settings
Solution 4: Verify form has CSRF field
```

---

## 📱 Contact Information

### Emergency (Security Breach)
- Email: security@urbannest.com
- Response Time: < 2 hours

### General Support
- Email: support@urbannest.com
- Response Time: < 24 hours

### Documentation
- README.md - Overview
- INSTALLATION.md - Setup guide
- SECURITY.md - Security details
- VULNERABILITY_ANALYSIS.md - What was fixed

---

## 🔍 Security Testing Commands

### Test SQL Injection
```
Username: admin' OR '1'='1
Should: FAIL (protected)
```

### Test CSRF
```bash
curl -X POST https://site.com/admin/action.php -d "data=test"
Should: FAIL without token
```

### Test Rate Limiting
```
Try 6 failed logins in a row
Should: Block on 6th attempt
```

### Test File Upload
```
Upload: shell.php.png
Should: REJECTED
```

---

## 📊 Monitoring

### What to Monitor
- Failed login attempts (> 3 from same IP)
- Unusual file uploads
- Database errors
- Server resource usage
- Backup success/failure
- Disk space

### Log Locations
```
PHP Errors: logs/php-error.log
Access Log: /var/log/apache2/access.log
Error Log: /var/log/apache2/error.log
MySQL Log: /var/log/mysql/error.log
```

---

## 🎯 Quick Actions

### Lock Account Manually
```sql
UPDATE user SET status = 'locked' WHERE username = 'username';
```

### Unlock Account
```sql
UPDATE user SET status = 'active' WHERE username = 'username';
```

### Reset Login Attempts
```sql
DELETE FROM login_attempts WHERE username = 'username';
```

### Enable Maintenance Mode
Create file: `maintenance.php`
```php
<?php die("Under maintenance. Please check back soon."); ?>
```
Include at top of all pages.

---

## 💾 Backup Schedule

- **Hourly:** Session data (auto)
- **Daily:** Database (automated)
- **Weekly:** Full system backup
- **Monthly:** Off-site backup copy
- **Quarterly:** Test restoration

---

## 🔐 Security Headers Check

```bash
curl -I https://yoursite.com/admin/ | grep -E "X-Frame|X-Content|X-XSS|Referrer|Content-Security"
```

Should show:
```
X-Frame-Options: SAMEORIGIN
X-Content-Type-Options: nosniff
X-XSS-Protection: 1; mode=block
Referrer-Policy: strict-origin-when-cross-origin
Content-Security-Policy: default-src 'self'
```

---

## 📞 Support Escalation

1. Check documentation
2. Review error logs
3. Search known issues
4. Email support
5. Emergency contact (critical only)

---

**Keep this card handy for quick reference!**

Last Updated: January 2026
Version: 2.0
