# 🏠 Urban Nest Admin Panel - Secure Version 2.0

A **production-ready, secure** admin panel for managing rental properties, built with comprehensive security features.

## ⚠️ Original System Status: CRITICAL VULNERABILITIES

Your original admin panel had **10+ critical security vulnerabilities** including:
- SQL Injection (Complete database compromise possible)
- Plain text passwords
- No CSRF protection
- Insecure file uploads
- No input validation
- No rate limiting
- XSS vulnerabilities
- Session hijacking risks

**See VULNERABILITY_ANALYSIS.md for complete details**

---

## ✨ Features

### Core Functionality
- 🏢 **Tenant Management** - Add, edit, delete property listings
- 🖼️ **Gallery Management** - Manage property images
- 👥 **User Management** - Secure authentication system
- 📊 **Dashboard** - Statistics and recent activity
- 🔍 **Search & Filter** - Find properties quickly

### Security Features
- 🔒 **SQL Injection Protection** - PDO prepared statements
- 🔐 **Password Hashing** - Bcrypt algorithm
- 🛡️ **CSRF Protection** - Token-based validation
- 📁 **Secure File Uploads** - Multiple validation layers
- ⏱️ **Rate Limiting** - Brute force prevention
- 🔑 **Session Security** - Fingerprinting & timeout
- 🚫 **XSS Prevention** - Output escaping
- 📝 **Input Validation** - Comprehensive sanitization
- 🔐 **Secure Headers** - OWASP recommended
- 📊 **Audit Logging** - Track all activities

---

## 🚀 Quick Start

### Requirements
- PHP 7.4+ (8.0+ recommended)
- MySQL 5.7+ / MariaDB 10.3+
- Apache/Nginx with mod_rewrite
- SSL Certificate (production)

### Installation

1. **Upload Files**
```bash
# Upload all files to your server
/var/www/html/admin/
```

2. **Set Permissions**
```bash
cd /var/www/html/admin
chmod 755 .
chmod 755 uploads logs
chmod 644 *.php
```

3. **Create Database**
```bash
mysql -u root -p < database_schema.sql
```

4. **Configure**
Edit `config.php`:
```php
define('DB_USER', 'your_db_user');
define('DB_PASS', 'your_db_password');
define('SITE_URL', 'https://yourdomain.com');
```

5. **Login**
```
URL: https://yourdomain.com/admin/login.php
Username: admin
Password: Admin@123
```

**⚠️ CHANGE PASSWORD IMMEDIATELY!**

See [INSTALLATION.md](INSTALLATION.md) for detailed instructions.

---

## 📚 Documentation

| Document | Description |
|----------|-------------|
| [INSTALLATION.md](INSTALLATION.md) | Complete setup guide |
| [SECURITY.md](SECURITY.md) | Security features & best practices |
| [VULNERABILITY_ANALYSIS.md](VULNERABILITY_ANALYSIS.md) | Original vulnerabilities & fixes |
| [database_schema.sql](database_schema.sql) | Database structure |

---

## 🔒 Security Improvements

### Original vs Secure Comparison

| Feature | Original | Secure |
|---------|----------|--------|
| SQL Queries | ❌ String concatenation | ✅ PDO prepared statements |
| Passwords | ❌ Plain text | ✅ Bcrypt hashed |
| CSRF | ❌ No protection | ✅ Token validation |
| File Uploads | ❌ No validation | ✅ Multi-layer validation |
| Sessions | ❌ Basic | ✅ Hardened (fingerprint, timeout) |
| Input | ❌ No validation | ✅ Comprehensive validation |
| Rate Limit | ❌ None | ✅ 5 attempts / 15 min |
| XSS | ❌ Vulnerable | ✅ All output escaped |
| Errors | ❌ Exposed | ✅ Generic + logged |

---

## 🎯 Code Examples

### Before (VULNERABLE)
```php
// SQL Injection vulnerable
$sql = "SELECT * FROM user WHERE username='$username'";

// Plain text password
INSERT INTO user VALUES ('admin', 'password123');

// No file validation
move_uploaded_file($_FILES['file']['tmp_name'], 'uploads/' . $_FILES['file']['name']);
```

### After (SECURE)
```php
// Protected with prepared statements
$stmt = $db->prepare("SELECT * FROM user WHERE username = ?");
$stmt->execute([$username]);

// Hashed password
$hash = password_hash('password123', PASSWORD_DEFAULT);

// Validated upload
$result = FileUploadHandler::uploadImage($_FILES['file']);
```

---

## 🛠️ Configuration

### Environment Variables (.env)
```env
DB_HOST=localhost
DB_USER=urban_nest_user
DB_PASS=your_secure_password
DB_NAME=db_urban_nest
SITE_URL=https://yourdomain.com
ADMIN_EMAIL=admin@yourdomain.com
```

### Security Settings
```php
// config.php
define('SESSION_LIFETIME', 3600);      // 1 hour
define('MAX_LOGIN_ATTEMPTS', 5);       // 5 attempts
define('LOGIN_LOCKOUT_TIME', 900);     // 15 minutes
define('MAX_FILE_SIZE', 5242880);      // 5MB
```

---

## 🔐 Default Credentials

**⚠️ For first login only - CHANGE IMMEDIATELY**

- **Username:** admin
- **Password:** Admin@123

### Changing Password
```bash
# Generate new hash
php -r "echo password_hash('YourNewPassword', PASSWORD_DEFAULT);"

# Update in database
mysql -u root -p
USE db_urban_nest;
UPDATE user SET password='PASTE_HASH_HERE' WHERE username='admin';
```

---

## 📊 Database Schema

### Main Tables
- `user` - Admin users with hashed passwords
- `tenant` - Property listings
- `gallery` - Image gallery
- `login_attempts` - Rate limiting data
- `activity_log` - Audit trail

See [database_schema.sql](database_schema.sql) for complete structure.

---

## 🧪 Testing Security

### Test CSRF Protection
```bash
curl -X POST https://yourdomain.com/admin/addTenant.php \
  -d "totalRooms=3&address=Test"
# Should fail without CSRF token
```

### Test SQL Injection
```
Username: admin' OR '1'='1
Password: anything
# Should fail (protected by prepared statements)
```

### Test Rate Limiting
```bash
# Try 6 failed logins
# 6th attempt should be blocked
```

---

## 📝 Best Practices

### Development
- [ ] Use version control (Git)
- [ ] Never commit `.env` files
- [ ] Test in staging environment
- [ ] Review code for security issues
- [ ] Keep dependencies updated

### Production
- [ ] Always use HTTPS
- [ ] Enable security headers
- [ ] Regular backups (daily)
- [ ] Monitor error logs
- [ ] Update software regularly
- [ ] Use strong passwords
- [ ] Limit database privileges

---

## 🚨 Emergency Procedures

### If Breach Suspected
1. Immediately disable site
2. Change all passwords
3. Review access logs
4. Check for unauthorized changes
5. Restore from backup if needed
6. Enable additional logging
7. Contact security team

### Backup & Recovery
```bash
# Backup
mysqldump -u user -p db_urban_nest > backup.sql
tar -czf backup_files.tar.gz /var/www/html/admin

# Restore
mysql -u user -p db_urban_nest < backup.sql
tar -xzf backup_files.tar.gz
```

---

## 📈 Performance

### Optimization Tips
- Enable OPcache
- Use CDN for static assets
- Optimize images before upload
- Enable gzip compression
- Use database indexes (already included)
- Cache frequently accessed data

---

## 🤝 Support & Maintenance

### Regular Tasks
- **Daily:** Review error logs
- **Weekly:** Check access logs
- **Monthly:** Update software, test backups
- **Quarterly:** Security audit, password rotation

### Getting Help
- 📧 Email: support@urbannest.com
- 📖 Documentation: See docs folder
- 🐛 Report bugs: [Create issue]

---

## 📜 License

Proprietary - Urban Nest Admin Panel

---

## 🙏 Credits

**Security Implementation:** Enterprise-grade security standards
**Based on:** OWASP Top 10, PHP Security Best Practices
**Tested against:** Common web vulnerabilities

---

## ⚠️ Important Notes

1. **Original system was critically insecure** - DO NOT use in production
2. **Secure version implements industry standards** - Safe for production
3. **Change default credentials immediately** after first login
4. **Enable HTTPS** before going live
5. **Regular updates required** for continued security
6. **Backup frequently** - Test restores monthly

---

## 🎓 Learning Resources

- [OWASP Top 10](https://owasp.org/www-project-top-ten/)
- [PHP Security](https://www.php.net/manual/en/security.php)
- [MySQL Security](https://dev.mysql.com/doc/refman/8.0/en/security.html)
- [Web Security Testing](https://owasp.org/www-project-web-security-testing-guide/)

---

## 📞 Contact

For security issues or urgent support:
- 🔒 Security: security@urbannest.com (private disclosure)
- 💬 General: support@urbannest.com

---

**Version:** 2.0 (Secure Release)  
**Last Updated:** January 2026  
**Status:** Production Ready ✅

---

Remember: **Security is not a feature, it's a requirement.** This system implements best practices to protect your data and users. Stay vigilant and keep it updated!
