<?php
require_once 'config.php';
require_once 'db.php';
require_once 'SecureSession.php';
require_once 'InputValidator.php';

SecureSession::init();

// Redirect if already logged in
if (SecureSession::isLoggedIn()) {
    header('Location: dashboard.php');
    exit();
}

$error = '';
$loginAttempts = $_SESSION['login_attempts'] ?? 0;
$lastAttemptTime = $_SESSION['last_attempt_time'] ?? 0;

// Handle login form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // Rate limiting
    if ($loginAttempts >= MAX_LOGIN_ATTEMPTS) {
        $timeSinceLastAttempt = time() - $lastAttemptTime;
        if ($timeSinceLastAttempt < LOGIN_LOCKOUT_TIME) {
            $remainingTime = ceil((LOGIN_LOCKOUT_TIME - $timeSinceLastAttempt) / 60);
            $error = "Too many login attempts. Please try again in {$remainingTime} minute(s).";
        } else {
            // Reset attempts after lockout period
            $_SESSION['login_attempts'] = 0;
        }
    }
    
    if (empty($error)) {
        // Validate CSRF token
        if (!isset($_POST['csrf_token']) || !SecureSession::validateCSRFToken($_POST['csrf_token'])) {
            $error = "Invalid security token. Please refresh and try again.";
        } else {
            $username = $_POST['username'] ?? '';
            $password = $_POST['password'] ?? '';
            
            // Validate required fields
            if (empty($username) || empty($password)) {
                $error = "Username and password are required";
            } else {
                // Sanitize input
                $username = InputValidator::sanitizeString($username);
                
                try {
                    $db = getDB();
                    
                    // Use prepared statement to prevent SQL injection
                    $stmt = $db->prepare("SELECT id, username, password FROM user WHERE username = ? LIMIT 1");
                    $stmt->execute([$username]);
                    $user = $stmt->fetch();
                    
                    // Verify password using password_verify
                    if ($user && password_verify($password, $user['password'])) {
                        // Successful login
                        $_SESSION['login_attempts'] = 0;
                        SecureSession::login($user['username']);
                        
                        // Log successful login
                        error_log("Successful login: {$user['username']} from {$_SERVER['REMOTE_ADDR']}");
                        
                        header('Location: dashboard.php');
                        exit();
                    } else {
                        // Failed login
                        $_SESSION['login_attempts'] = $loginAttempts + 1;
                        $_SESSION['last_attempt_time'] = time();
                        
                        // Log failed attempt
                        error_log("Failed login attempt for username: {$username} from {$_SERVER['REMOTE_ADDR']}");
                        
                        $error = "Invalid username or password";
                    }
                } catch (PDOException $e) {
                    error_log("Login error: " . $e->getMessage());
                    $error = "An error occurred. Please try again later.";
                }
            }
        }
    }
}

// Handle GET error messages
if (isset($_GET['error'])) {
    switch ($_GET['error']) {
        case 'auth_required':
            $error = "Please login to access this page";
            break;
        case 'session_hijack':
            $error = "Security violation detected. Please login again.";
            break;
        case 'logout':
            $error = "You have been logged out successfully";
            break;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Urban Nest Admin</title>
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .login-container {
            background: white;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
            max-width: 400px;
            width: 100%;
        }
        .login-header {
            text-align: center;
            margin-bottom: 30px;
        }
        .login-header h1 {
            color: #333;
            font-size: 28px;
            margin-bottom: 10px;
        }
        .alert {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-header">
            <h1>Urban Nest Admin</h1>
            <p class="text-muted">Secure Login Portal</p>
        </div>
        
        <?php if (!empty($error)): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo InputValidator::escapeOutput($error); ?>
            </div>
        <?php endif; ?>
        
        <form method="POST" action="login.php">
            <?php echo SecureSession::getCSRFField(); ?>
            
            <div class="mb-3">
                <label for="username" class="form-label">Username</label>
                <input type="text" class="form-control" id="username" name="username" 
                       required autocomplete="username" maxlength="50"
                       value="<?php echo isset($_POST['username']) ? InputValidator::escapeOutput($_POST['username']) : ''; ?>">
            </div>
            
            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" class="form-control" id="password" name="password" 
                       required autocomplete="current-password" maxlength="100">
            </div>
            
            <div class="mb-3 form-check">
                <input type="checkbox" class="form-check-input" id="remember" name="remember">
                <label class="form-check-label" for="remember">Remember me</label>
            </div>
            
            <button type="submit" class="btn btn-primary w-100">Login</button>
        </form>
        
        <div class="text-center mt-3">
            <small class="text-muted">
                Login attempts: <?php echo $loginAttempts; ?> / <?php echo MAX_LOGIN_ATTEMPTS; ?>
            </small>
        </div>
    </div>
    
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>
